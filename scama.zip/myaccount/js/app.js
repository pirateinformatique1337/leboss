function showContent(){
	document.querySelector('.spinner').classList.add('hidden')


}

setTimeout(showContent, 100);

